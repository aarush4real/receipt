"import { format } from \"date-fns\";
import { Activity } from \"lucide-react\";

const fmtMoney = (n) =>
  new Intl.NumberFormat(\"en-IN\", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number.isFinite(n) ? n : 0);

export default function ReceiptPreview({
  clinicName,
  date,
  rows,
  subtotal,
  total,
  receiptNo,
}) {
  const visibleRows = rows.filter(
    (r) => r.name.trim() || r.qty || r.rate,
  );

  return (
    <div
      id=\"printable-receipt\"
      className=\"relative overflow-hidden rounded-2xl border border-stone-100 bg-white p-8 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.08)] md:p-12\"
      data-testid=\"receipt-preview\"
    >
      {/* Top corner accent */}
      <div className=\"pointer-events-none absolute right-0 top-0 h-32 w-32 -translate-y-1/2 translate-x-1/2 rounded-full bg-[#3f5243]/5\" />
      <div className=\"pointer-events-none absolute bottom-0 left-0 h-24 w-24 -translate-x-1/2 translate-y-1/2 rounded-full bg-[#9c8c5a]/5\" />

      {/* Brand header */}
      <div className=\"relative flex items-start justify-between gap-6 border-b border-stone-200 pb-6\">
        <div className=\"flex items-start gap-3\">
          <div className=\"flex h-12 w-12 items-center justify-center rounded-xl bg-[#3f5243] text-white\">
            <Activity className=\"h-5 w-5\" />
          </div>
          <div>
            <p className=\"text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-400\">
              Clinic Supply Receipt
            </p>
            <h2
              className=\"mt-1 text-2xl font-medium tracking-tight text-stone-900\"
              data-testid=\"text-clinic-name\"
            >
              {clinicName || \"Your Clinic Name\"}
            </h2>
          </div>
        </div>
        <div className=\"text-right\">
          <p className=\"text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-400\">
            Receipt No.
          </p>
          <p className=\"mt-1 font-mono text-sm text-stone-700\">{receiptNo}</p>
          <p className=\"mt-3 text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-400\">
            Date
          </p>
          <p
            className=\"mt-1 text-sm text-stone-700\"
            data-testid=\"text-receipt-date\"
          >
            {date ? format(date, \"PPP\") : \"—\"}
          </p>
        </div>
      </div>

      {/* Items table */}
      <div className=\"mt-8\">
        <table className=\"w-full text-sm\">
          <thead>
            <tr className=\"border-b-2 border-stone-800 text-left\">
              <th className=\"w-[8%] py-3 pr-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-500\">
                #
              </th>
              <th className=\"py-3 pr-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-500\">
                Product
              </th>
              <th className=\"w-[12%] py-3 pr-2 text-right text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-500\">
                Qty
              </th>
              <th className=\"w-[18%] py-3 pr-2 text-right text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-500\">
                Rate
              </th>
              <th className=\"w-[20%] py-3 text-right text-[10px] font-semibold uppercase tracking-[0.18em] text-stone-500\">
                Amount
              </th>
            </tr>
          </thead>
          <tbody data-testid=\"preview-rows\">
            {visibleRows.length === 0 && (
              <tr>
                <td
                  colSpan={5}
                  className=\"py-10 text-center text-sm italic text-stone-400\"
                >
                  Add products on the left to see them here.
                </td>
              </tr>
            )}
            {visibleRows.map((r, idx) => (
              <tr
                key={r.id}
                className=\"border-b border-stone-100\"
                data-testid={`preview-row-${idx}`}
              >
                <td className=\"py-4 pr-2 text-stone-500\">
                  {String(idx + 1).padStart(2, \"0\")}
                </td>
                <td className=\"py-4 pr-2 text-stone-800\">
                  {r.name || <span className=\"italic text-stone-400\">—</span>}
                </td>
                <td className=\"py-4 pr-2 text-right tabular-nums text-stone-700\">
                  {r.qty || 0}
                </td>
                <td className=\"py-4 pr-2 text-right tabular-nums text-stone-700\">
                  {fmtMoney(parseFloat(r.rate) || 0)}
                </td>
                <td className=\"py-4 text-right tabular-nums font-medium text-stone-900\">
                  {fmtMoney(r.amount)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals */}
      <div className=\"mt-8 flex justify-end\">
        <div className=\"w-full max-w-xs space-y-3\">
          <div className=\"flex items-center justify-between text-sm\">
            <span className=\"text-stone-500\">Subtotal</span>
            <span
              className=\"tabular-nums text-stone-800\"
              data-testid=\"text-receipt-subtotal\"
            >
              {fmtMoney(subtotal)}
            </span>
          </div>
          <div className=\"border-t border-stone-200 pt-3\" />
          <div className=\"flex items-baseline justify-between\">
            <span className=\"text-[10px] font-semibold uppercase tracking-[0.22em] text-stone-500\">
              Total
            </span>
            <span
              className=\"text-3xl font-medium tracking-tight text-[#3f5243] tabular-nums\"
              data-testid=\"text-receipt-total\"
            >
              ₹{fmtMoney(total)}
            </span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className=\"mt-10 flex flex-col gap-4 border-t border-stone-200 pt-6 text-xs text-stone-500 sm:flex-row sm:items-center sm:justify-between\">
        <p>Thank you for your purchase. Please keep this receipt for your records.</p>
        <p className=\"font-mono text-stone-400\">Issued by Clinic Supply</p>
      </div>
    </div>
  );
}
"