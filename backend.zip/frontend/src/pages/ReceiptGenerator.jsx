"import { useMemo, useState } from \"react\";
import { format } from \"date-fns\";
import {
  Activity,
  CalendarIcon,
  Plus,
  Printer,
  Download,
  Trash2,
  RotateCcw,
} from \"lucide-react\";
import { toast } from \"sonner\";

import { Button } from \"@/components/ui/button\";
import { Input } from \"@/components/ui/input\";
import { Label } from \"@/components/ui/label\";
import { Card } from \"@/components/ui/card\";
import { Calendar } from \"@/components/ui/calendar\";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from \"@/components/ui/popover\";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from \"@/components/ui/table\";

import ReceiptPreview from \"@/components/ReceiptPreview\";

const newRow = () => ({
  id: crypto.randomUUID(),
  name: \"\",
  qty: \"\",
  rate: \"\",
});

const genReceiptNo = () => {
  const d = new Date();
  const s = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, \"0\")}${String(d.getDate()).padStart(2, \"0\")}`;
  const r = Math.floor(1000 + Math.random() * 9000);
  return `RX-${s}-${r}`;
};

export default function ReceiptGenerator() {
  const [date, setDate] = useState(new Date());
  const [clinicName, setClinicName] = useState(\"\");
  const [items, setItems] = useState([newRow(), newRow()]);
  const [receiptNo, setReceiptNo] = useState(genReceiptNo());

  const updateItem = (id, field, value) => {
    setItems((prev) =>
      prev.map((it) => (it.id === id ? { ...it, [field]: value } : it)),
    );
  };

  const addRow = () => setItems((prev) => [...prev, newRow()]);
  const removeRow = (id) =>
    setItems((prev) => (prev.length > 1 ? prev.filter((it) => it.id !== id) : prev));

  const reset = () => {
    setDate(new Date());
    setClinicName(\"\");
    setItems([newRow(), newRow()]);
    setReceiptNo(genReceiptNo());
    toast.success(\"Form cleared\");
  };

  const computed = useMemo(() => {
    const rows = items.map((it) => {
      const qty = parseFloat(it.qty) || 0;
      const rate = parseFloat(it.rate) || 0;
      return { ...it, amount: +(qty * rate).toFixed(2) };
    });
    const subtotal = +rows.reduce((s, r) => s + r.amount, 0).toFixed(2);
    return { rows, subtotal, total: subtotal };
  }, [items]);

  const canGenerate =
    clinicName.trim().length > 0 &&
    computed.rows.some((r) => r.name.trim() && r.amount > 0);

  const handlePrint = () => {
    if (!canGenerate) {
      toast.error(\"Please fill clinic name and at least one valid item\");
      return;
    }
    window.print();
  };

  const handleDownload = () => {
    if (!canGenerate) {
      toast.error(\"Please fill clinic name and at least one valid item\");
      return;
    }
    toast.info(\"In the print dialog, choose 'Save as PDF' as destination\", {
      duration: 4000,
    });
    setTimeout(() => window.print(), 400);
  };

  return (
    <div
      className=\"app-bg grain-overlay relative min-h-screen text-stone-900\"
      data-testid=\"page-receipt-generator\"
    >
      <div className=\"relative z-10 mx-auto max-w-7xl px-5 py-8 md:px-10 md:py-12\">
        {/* Header */}
        <header className=\"no-print mb-10 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between\">
          <div className=\"flex items-center gap-3\">
            <div className=\"flex h-11 w-11 items-center justify-center rounded-xl bg-[#3f5243] text-white shadow-sm\">
              <Activity className=\"h-5 w-5\" />
            </div>
            <div>
              <p className=\"text-xs font-semibold uppercase tracking-[0.18em] text-stone-500\">
                Clinic Supply
              </p>
              <h1 className=\"text-2xl font-medium tracking-tight text-stone-900 sm:text-3xl\">
                Receipt Generator
              </h1>
            </div>
          </div>
          <p className=\"max-w-md text-sm leading-relaxed text-stone-500\">
            Fill the details on the left. Your receipt preview updates live on the
            right. Print or save as PDF when ready.
          </p>
        </header>

        {/* Two-column layout */}
        <div className=\"grid grid-cols-1 gap-8 lg:grid-cols-12 lg:gap-10\">
          {/* ---------- FORM ---------- */}
          <Card
            className=\"no-print col-span-1 border border-white/60 bg-white/80 p-6 backdrop-blur-xl md:p-8 lg:col-span-5\"
            data-testid=\"form-card\"
          >
            <div className=\"mb-6 flex items-center justify-between\">
              <h2 className=\"text-lg font-medium tracking-tight text-stone-800\">
                Receipt Details
              </h2>
              <Button
                type=\"button\"
                variant=\"ghost\"
                size=\"sm\"
                onClick={reset}
                className=\"text-stone-500 hover:text-stone-800\"
                data-testid=\"btn-reset\"
              >
                <RotateCcw className=\"mr-2 h-3.5 w-3.5\" />
                Reset
              </Button>
            </div>

            <div className=\"space-y-5\">
              {/* Date */}
              <div className=\"space-y-2\">
                <Label className=\"text-xs font-semibold uppercase tracking-[0.15em] text-stone-500\">
                  Date
                </Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant=\"outline\"
                      className=\"w-full justify-start border-stone-200 bg-white font-normal text-stone-800 hover:bg-stone-50\"
                      data-testid=\"btn-date-picker\"
                    >
                      <CalendarIcon className=\"mr-2 h-4 w-4 text-stone-500\" />
                      {date ? format(date, \"PPP\") : \"Pick a date\"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className=\"w-auto p-0\" align=\"start\">
                    <Calendar
                      mode=\"single\"
                      selected={date}
                      onSelect={(d) => d && setDate(d)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Clinic Name */}
              <div className=\"space-y-2\">
                <Label
                  htmlFor=\"clinic-name\"
                  className=\"text-xs font-semibold uppercase tracking-[0.15em] text-stone-500\"
                >
                  Clinic Name
                </Label>
                <Input
                  id=\"clinic-name\"
                  placeholder=\"e.g. Greenleaf Family Clinic\"
                  value={clinicName}
                  onChange={(e) => setClinicName(e.target.value)}
                  className=\"border-stone-200 bg-white focus-visible:border-[#3f5243] focus-visible:ring-1 focus-visible:ring-[#3f5243]\"
                  data-testid=\"input-clinic-name\"
                />
              </div>

              {/* Receipt # (read only display) */}
              <div className=\"space-y-2\">
                <Label className=\"text-xs font-semibold uppercase tracking-[0.15em] text-stone-500\">
                  Receipt Number
                </Label>
                <div
                  className=\"rounded-md border border-stone-200 bg-stone-50 px-3 py-2 font-mono text-sm text-stone-700\"
                  data-testid=\"text-receipt-no\"
                >
                  {receiptNo}
                </div>
              </div>
            </div>

            {/* Line items */}
            <div className=\"mt-8\">
              <div className=\"mb-3 flex items-center justify-between\">
                <h3 className=\"text-sm font-semibold uppercase tracking-[0.15em] text-stone-500\">
                  Products
                </h3>
                <Button
                  type=\"button\"
                  size=\"sm\"
                  onClick={addRow}
                  className=\"bg-[#3f5243] text-white shadow-sm hover:bg-[#2d3a2f]\"
                  data-testid=\"btn-add-row\"
                >
                  <Plus className=\"mr-1.5 h-4 w-4\" />
                  Add row
                </Button>
              </div>

              <div className=\"overflow-x-auto\">
                <Table>
                  <TableHeader>
                    <TableRow className=\"border-b-2 border-stone-800 hover:bg-transparent\">
                      <TableHead className=\"w-[44%] px-2 text-stone-700\">Product</TableHead>
                      <TableHead className=\"w-[18%] px-2 text-right text-stone-700\">Qty</TableHead>
                      <TableHead className=\"w-[24%] px-2 text-right text-stone-700\">Rate</TableHead>
                      <TableHead className=\"w-[14%] px-2 text-right text-stone-700\"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.map((it, idx) => (
                      <TableRow
                        key={it.id}
                        className=\"border-b border-stone-100 hover:bg-transparent\"
                        data-testid={`form-row-${idx}`}
                      >
                        <TableCell className=\"px-2 py-3\">
                          <Input
                            placeholder=\"Product name\"
                            value={it.name}
                            onChange={(e) =>
                              updateItem(it.id, \"name\", e.target.value)
                            }
                            className=\"h-9 border-stone-200 bg-white focus-visible:border-[#3f5243] focus-visible:ring-1 focus-visible:ring-[#3f5243]\"
                            data-testid={`input-product-name-${idx}`}
                          />
                        </TableCell>
                        <TableCell className=\"px-2 py-3 text-right\">
                          <Input
                            type=\"number\"
                            min=\"0\"
                            step=\"1\"
                            placeholder=\"0\"
                            value={it.qty}
                            onChange={(e) =>
                              updateItem(it.id, \"qty\", e.target.value)
                            }
                            className=\"h-9 border-stone-200 bg-white text-right focus-visible:border-[#3f5243] focus-visible:ring-1 focus-visible:ring-[#3f5243]\"
                            data-testid={`input-qty-${idx}`}
                          />
                        </TableCell>
                        <TableCell className=\"px-2 py-3 text-right\">
                          <Input
                            type=\"number\"
                            min=\"0\"
                            step=\"0.01\"
                            placeholder=\"0.00\"
                            value={it.rate}
                            onChange={(e) =>
                              updateItem(it.id, \"rate\", e.target.value)
                            }
                            className=\"h-9 border-stone-200 bg-white text-right focus-visible:border-[#3f5243] focus-visible:ring-1 focus-visible:ring-[#3f5243]\"
                            data-testid={`input-rate-${idx}`}
                          />
                        </TableCell>
                        <TableCell className=\"px-2 py-3 text-right\">
                          <Button
                            type=\"button\"
                            variant=\"ghost\"
                            size=\"icon\"
                            onClick={() => removeRow(it.id)}
                            disabled={items.length <= 1}
                            className=\"h-8 w-8 text-stone-400 hover:bg-[#9c4c4c]/10 hover:text-[#9c4c4c]\"
                            data-testid={`btn-remove-row-${idx}`}
                          >
                            <Trash2 className=\"h-4 w-4\" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* Actions */}
            <div className=\"mt-8 flex flex-col gap-3 sm:flex-row\">
              <Button
                type=\"button\"
                onClick={handlePrint}
                className=\"flex-1 bg-[#3f5243] text-white shadow-sm hover:bg-[#2d3a2f]\"
                data-testid=\"btn-print-receipt\"
              >
                <Printer className=\"mr-2 h-4 w-4\" />
                Print
              </Button>
              <Button
                type=\"button\"
                onClick={handleDownload}
                variant=\"secondary\"
                className=\"flex-1 bg-[#e2e8e3] text-[#3f5243] hover:bg-[#d1dcd3]\"
                data-testid=\"btn-download-pdf\"
              >
                <Download className=\"mr-2 h-4 w-4\" />
                Download PDF
              </Button>
            </div>
          </Card>

          {/* ---------- PREVIEW ---------- */}
          <div className=\"col-span-1 lg:col-span-7\">
            <ReceiptPreview
              clinicName={clinicName}
              date={date}
              rows={computed.rows}
              subtotal={computed.subtotal}
              total={computed.total}
              receiptNo={receiptNo}
            />
          </div>
        </div>

        <footer className=\"no-print mt-10 text-center text-xs text-stone-400\">
          Designed for clinics. Live preview updates as you type.
        </footer>
      </div>
    </div>
  );
}
"